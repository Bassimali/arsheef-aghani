package com.arsheef.aghani

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.text.Normalizer

private const val ARCHIVE_FOLDER_NAME = "أرشيف أغنياتي"
private const val ARCHIVE_FILE_NAME = "أرشيف أغنياتي.json"

private data class SongVersion(val number: Int, val lyrics: String, val savedAt: Long = System.currentTimeMillis())
private data class Song(val id: String, val title: String, val versions: List<SongVersion>)

class MainActivity : ComponentActivity() {
    private var folderPickerCallback: ((Uri?) -> Unit)? = null
    private val folderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { parentUri ->
        var archiveUri: Uri? = null
        if (parentUri != null) {
            try {
                contentResolver.takePersistableUriPermission(
                    parentUri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
                val picked = DocumentFile.fromTreeUri(this, parentUri)
                val archiveDir = if (picked?.name == ARCHIVE_FOLDER_NAME) {
                    picked
                } else {
                    picked?.findFile(ARCHIVE_FOLDER_NAME)?.takeIf { it.isDirectory }
                        ?: picked?.createDirectory(ARCHIVE_FOLDER_NAME)
                }
                if (archiveDir != null && archiveDir.isDirectory) {
                    // Keep the original tree URI, which retains Android's persisted folder permission.
                    archiveUri = parentUri
                    getSharedPreferences("archive", MODE_PRIVATE).edit()
                        .putString("folder", parentUri.toString()).apply()
                }
            } catch (_: Exception) {
                Toast.makeText(this, "تعذر إنشاء مجلد الأرشيف في هذا المكان. اختر مجلدًا آخر.", Toast.LENGTH_LONG).show()
            }
        }
        folderPickerCallback?.invoke(archiveUri)
        folderPickerCallback = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ArchiveApp(
            readArchive = { readArchive() },
            writeArchive = { songs -> writeArchive(songs) },
            chooseFolder = { callback -> folderPickerCallback = callback; folderPicker.launch(null) },
            getFolder = { getSharedPreferences("archive", MODE_PRIVATE).getString("folder", null)?.let(Uri::parse) }
        ) }
    }

    private fun archiveFile(): DocumentFile? {
        val raw = getSharedPreferences("archive", MODE_PRIVATE).getString("folder", null) ?: return null
        val picked = DocumentFile.fromTreeUri(this, Uri.parse(raw)) ?: return null
        val archiveDir = if (picked.name == ARCHIVE_FOLDER_NAME) picked else
            picked.findFile(ARCHIVE_FOLDER_NAME)?.takeIf { it.isDirectory }
                ?: picked.createDirectory(ARCHIVE_FOLDER_NAME)
                ?: return null
        return archiveDir.findFile(ARCHIVE_FILE_NAME)
            ?: archiveDir.createFile("application/json", ARCHIVE_FILE_NAME)
    }

    private fun readArchive(): List<Song> {
        return try {
            val file = archiveFile() ?: return emptyList()
            val text = contentResolver.openInputStream(file.uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: return emptyList()
            val root = JSONObject(text); val arr = root.optJSONArray("songs") ?: JSONArray()
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i); val versionsJson = obj.optJSONArray("versions") ?: JSONArray()
                    val versions = buildList {
                        for (j in 0 until versionsJson.length()) {
                            val v = versionsJson.getJSONObject(j)
                            add(SongVersion(v.optInt("number", j + 1), v.optString("lyrics"), v.optLong("savedAt", 0L)))
                        }
                    }
                    add(Song(obj.optString("id"), obj.optString("title", "أغنية بلا عنوان"), versions))
                }
            }
        } catch (_: Exception) { emptyList() }
    }

    private fun writeArchive(songs: List<Song>): Boolean {
        return try {
            val file = archiveFile() ?: return false
            val arr = JSONArray()
            songs.forEach { song ->
                val vs = JSONArray()
                song.versions.forEach { v -> vs.put(JSONObject().put("number", v.number).put("lyrics", v.lyrics).put("savedAt", v.savedAt)) }
                arr.put(JSONObject().put("id", song.id).put("title", song.title).put("versions", vs))
            }
            val root = JSONObject().put("format", 1).put("songs", arr)
            contentResolver.openOutputStream(file.uri, "wt")?.bufferedWriter(Charsets.UTF_8)?.use { it.write(root.toString(2)) } ?: return false
            true
        } catch (_: Exception) { false }
    }
}

private fun normalized(s: String): String = Normalizer.normalize(s, Normalizer.Form.NFD)
    .replace(Regex("[\\u064B-\\u065F\\u0670\\u0640]"), "")
    .lowercase().trim()

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ArchiveApp(
    readArchive: () -> List<Song>,
    writeArchive: (List<Song>) -> Boolean,
    chooseFolder: (((Uri?) -> Unit) -> Unit),
    getFolder: () -> Uri?
) {
    val context = LocalContext.current
    var songs by remember { mutableStateOf(readArchive()) }
    var folder by remember { mutableStateOf(getFolder()) }
    var query by remember { mutableStateOf("") }
    var selectedSong by remember { mutableStateOf<String?>(null) }
    var selectedVersion by remember { mutableIntStateOf(0) }
    var editing by remember { mutableStateOf(false) }
    var draftTitle by remember { mutableStateOf("") }
    var draftLyrics by remember { mutableStateOf("") }
    var showNew by remember { mutableStateOf(false) }
    var newTitle by remember { mutableStateOf("") }
    var newLyrics by remember { mutableStateOf("") }
    var showFolderHelp by remember { mutableStateOf(false) }

    fun persist(updated: List<Song>) {
        if (folder == null) {
            Toast.makeText(context, "اختر مجلد الأرشيف أولًا لحفظ كلماتك خارجه", Toast.LENGTH_LONG).show()
            return
        }
        if (writeArchive(updated)) { songs = updated; Toast.makeText(context, "تم حفظ الأرشيف", Toast.LENGTH_SHORT).show() }
        else Toast.makeText(context, "تعذر الحفظ. اختر مجلدًا يمكن الكتابة فيه", Toast.LENGTH_LONG).show()
    }

    val currentSong = songs.firstOrNull { it.id == selectedSong }
    val currentVersion = currentSong?.versions?.firstOrNull { it.number == selectedVersion }

    MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF087E8B), secondary = androidx.compose.ui.graphics.Color(0xFFDAA520))) {
        Scaffold(topBar = {
            TopAppBar(
                title = { Text(if (editing) "تعديل نسخة" else if (currentSong != null) currentSong.title else "أرشيف أغنياتي", fontWeight = FontWeight.Bold) },
                navigationIcon = { if (currentSong != null || editing) IconButton(onClick = { if (editing) editing = false else selectedSong = null }) { Icon(Icons.Default.ArrowBack, "رجوع") } },
                actions = { if (currentSong == null && !editing) IconButton(onClick = { showFolderHelp = true }) { Icon(Icons.Default.FolderOpen, "مجلد الأرشيف") } }
            )
        }, floatingActionButton = {
            if (currentSong == null && !editing) FloatingActionButton(onClick = { showNew = true }) { Icon(Icons.Default.Add, "أغنية جديدة") }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
                if (folder == null) {
                    Card(Modifier.fillMaxWidth().padding(top = 10.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("اختر مجلدًا دائمًا للأرشيف", fontWeight = FontWeight.Bold)
                            Text("اختر المكان الأب الذي تريد الحفظ داخله، مثل ذاكرة الهاتف أو Documents. سينشئ التطبيق مجلد «أرشيف أغنياتي» وداخله ملف «أرشيف أغنياتي.json». بعد إعادة التثبيت اختر المكان الأب نفسه لاستعادة الأرشيف.")
                            Button(onClick = { chooseFolder { uri -> folder = uri; if (uri != null) { val loaded = readArchive(); if (loaded.isNotEmpty()) songs = loaded; if (writeArchive(songs)) Toast.makeText(context, "تم تجهيز ملف الأرشيف", Toast.LENGTH_SHORT).show() } } }) { Text("اختيار مجلد الأرشيف") }
                        }
                    }
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 4.dp)) {
                        Icon(Icons.Default.FolderOpen, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Text("الأرشيف المحلي • مجلد: أرشيف أغنياتي", style = MaterialTheme.typography.labelMedium)
                        Spacer(Modifier.weight(1f))
                        TextButton(onClick = { chooseFolder { uri ->
                            folder = uri
                            if (uri != null) {
                                val loaded = readArchive()
                                if (loaded.isNotEmpty()) songs = loaded
                                else if (songs.isNotEmpty()) writeArchive(songs)
                            }
                        } }) { Text("تغيير المجلد") }
                    }
                }

                if (editing && currentSong != null) {
                    OutlinedTextField(value = draftTitle, onValueChange = { draftTitle = it }, label = { Text("عنوان الأغنية") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = draftLyrics, onValueChange = { draftLyrics = it }, label = { Text("الكلمات كاملة") }, modifier = Modifier.weight(1f).fillMaxWidth(), minLines = 10)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { editing = false }, modifier = Modifier.weight(1f)) { Text("إلغاء") }
                        Button(onClick = {
                            if (draftTitle.isBlank() || draftLyrics.isBlank()) Toast.makeText(context, "أدخل العنوان والكلمات", Toast.LENGTH_SHORT).show()
                            else {
                                val updated = songs.map { s -> if (s.id == currentSong.id) s.copy(title = draftTitle.trim(), versions = s.versions + SongVersion((s.versions.maxOfOrNull { it.number } ?: 0) + 1, draftLyrics)) else s }
                                persist(updated); selectedVersion = updated.firstOrNull { it.id == currentSong.id }?.versions?.lastOrNull()?.number ?: selectedVersion; editing = false
                            }
                        }, modifier = Modifier.weight(1f)) { Text("حفظ نسخة جديدة") }
                    }
                } else if (currentSong != null) {
                    if (currentVersion != null) {
                        Text("النسخة ${currentVersion.number}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(vertical = 8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            Button(onClick = { val clip = android.content.ClipData.newPlainText("lyrics", currentVersion.lyrics); (context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(clip); Toast.makeText(context, "تم نسخ الكلمات كاملة", Toast.LENGTH_SHORT).show() }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.ContentCopy, null); Spacer(Modifier.width(6.dp)); Text("نسخ كاملة") }
                            OutlinedButton(onClick = { draftTitle = currentSong.title; draftLyrics = currentVersion.lyrics; editing = true }, modifier = Modifier.weight(1f)) { Text("تعديل") }
                        }
                        Text(currentVersion.lyrics, modifier = Modifier.fillMaxWidth().weight(1f).padding(top = 12.dp).verticalScroll(rememberScrollState()), style = MaterialTheme.typography.bodyLarge)
                    }
                    HorizontalDivider(Modifier.padding(vertical = 8.dp))
                    Text("النسخ المحفوظة", fontWeight = FontWeight.Bold)
                    LazyColumn(Modifier.heightIn(max = 180.dp)) {
                        items(currentSong.versions.sortedByDescending { it.number }) { v ->
                            ListItem(headlineContent = { Text("${currentSong.title} ${v.number}") }, supportingContent = { Text(v.lyrics.replace('\n', ' ').take(90)) }, modifier = Modifier.clickable { selectedVersion = v.number })
                        }
                    }
                } else {
                    OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp), placeholder = { Text("ابحث بالعنوان أو أي بيت من الأغنية") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
                    if (songs.isEmpty()) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) { Text("لم تحفظ أي أغنية بعد", style = MaterialTheme.typography.titleMedium); Text("اضغط + لإضافة أول أغنية") } }
                    } else {
                        LazyColumn(Modifier.fillMaxSize()) {
                            val filtered = songs.filter { song -> query.isBlank() || normalized(song.title + " " + song.versions.joinToString(" ") { it.lyrics }).contains(normalized(query)) }.sortedBy { it.title }
                            items(filtered) { song ->
                                ListItem(
                                    headlineContent = { Text(song.title, fontWeight = FontWeight.SemiBold) },
                                    supportingContent = { Text("${song.versions.size} نسخة • ${song.versions.lastOrNull()?.lyrics?.replace('\n', ' ')?.take(65).orEmpty()}") },
                                    trailingContent = { Text("›", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary) },
                                    modifier = Modifier.clickable { selectedSong = song.id; selectedVersion = song.versions.maxOfOrNull { it.number } ?: 1 }
                                )
                                HorizontalDivider()
                            }
                        }
                    }
                }
            }
        }

        if (showNew) AlertDialog(
            onDismissRequest = { showNew = false },
            title = { Text("إضافة أغنية") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = newTitle, onValueChange = { newTitle = it }, label = { Text("عنوان الأغنية") }, singleLine = true)
                OutlinedTextField(value = newLyrics, onValueChange = { newLyrics = it }, label = { Text("ألصق الكلمات هنا") }, minLines = 5)
            } },
            confirmButton = { TextButton(onClick = {
                if (newTitle.isBlank() || newLyrics.isBlank()) Toast.makeText(context, "أدخل العنوان والكلمات", Toast.LENGTH_SHORT).show()
                else if (folder == null) Toast.makeText(context, "اختر مجلد الأرشيف أولًا", Toast.LENGTH_LONG).show()
                else {
                    val existing = songs.firstOrNull { normalized(it.title) == normalized(newTitle) }
                    val updated = if (existing == null) songs + Song(java.util.UUID.randomUUID().toString(), newTitle.trim(), listOf(SongVersion(1, newLyrics))) else songs.map { if (it.id == existing.id) it.copy(versions = it.versions + SongVersion((it.versions.maxOfOrNull { v -> v.number } ?: 0) + 1, newLyrics)) else it }
                    persist(updated); selectedSong = updated.firstOrNull { normalized(it.title) == normalized(newTitle) }?.id; selectedVersion = selectedSong?.let { id -> updated.first { it.id == id }.versions.last().number } ?: 1
                    newTitle = ""; newLyrics = ""; showNew = false
                }
            }) { Text("حفظ") } },
            dismissButton = { TextButton(onClick = { showNew = false }) { Text("إلغاء") } }
        )
        if (showFolderHelp) AlertDialog(onDismissRequest = { showFolderHelp = false }, title = { Text("ملف الأرشيف") }, text = { Text("اختر المكان الأب في ذاكرة الهاتف، مثل Documents. سينشئ التطبيق مجلد «أرشيف أغنياتي» وداخله ملف «أرشيف أغنياتي.json» يحتوي على كلمات الأغاني ونسخها فقط. بعد إعادة التثبيت اختر المكان الأب نفسه لتحميل الأرشيف مجددًا.") }, confirmButton = { TextButton(onClick = { showFolderHelp = false; chooseFolder { uri -> folder = uri; if (uri != null) songs = readArchive() } }) { Text("اختيار المجلد") } }, dismissButton = { TextButton(onClick = { showFolderHelp = false }) { Text("إغلاق") } })
    }
}
